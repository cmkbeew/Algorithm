package chap01.pracQ;

import java.util.Scanner;

// p.46: Q13
public class Square {

	public static void main(String[] args) {
		Scanner sn = new Scanner(System.in);
		int n;
		
		System.out.println("���簢���� ����մϴ�.");
		
		do {
			System.out.print("���� ����: ");
			n = sn.nextInt();
		}while(n<=0);
		
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
