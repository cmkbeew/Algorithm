package chap01.pracQ;

import java.util.Scanner;

public class Difference {
	
	public static void main(String[] args) {
		Scanner sn = new Scanner(System.in);
		System.out.print("a: "); int a = sn.nextInt();
		System.out.print("b: "); int b = sn.nextInt();
		
		do {
			System.out.println("a���� ū b�� ���� �Է����ּ���!");
			System.out.print("b: ");
			b = sn.nextInt();
		}while(a>=b);
		
		int dif = b - a; 
		
		System.out.println("b - a�� " + dif + "�Դϴ�.");
			
	}

}
