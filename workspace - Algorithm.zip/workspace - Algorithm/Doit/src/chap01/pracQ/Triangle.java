package chap01.pracQ;

import java.util.Scanner;

// p.49: Q14
public class Triangle {
	static void triangleLB(int n) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	static void triangleLU(int n) {
		for(int i=n; i>=1; i--) {
			for(int j=1; j<=i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	static void triangleRU(int n) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=i-1; j++) {
				System.out.print(" ");
			}
			for(int j=1; j<=n-i+1; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	static void triangleRB(int n) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n-i; j++) {
				System.out.print(" ");
			}
			for(int j=1; j<=i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		Scanner sn = new Scanner(System.in);
		int n;
		
		System.out.println("���� �Ʒ��� ������ �̵�ﰢ���� ����մϴ�.");
		
		do {
			System.out.print("�� �� �ﰢ���Դϱ�?: ");
			n = sn.nextInt();
		}while(n<=0);
		
		//triangleLB(n);
		//triangleLU(n);
		//triangleRU(n);
		triangleRB(n);
	}
}
