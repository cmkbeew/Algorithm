package chap02.pracQ;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

//p.68.Q4: �迭 b�� ��� ��Ҹ� �迭 a�� �����ϴ� �޼ҵ�
public class Copy {
	static void copy(int[] a, int[] b) {
		for(int i=0; i< a.length; i++) {
			b[i] = a[i];
		}
	}
	
	public static void main(String[] args) {
		Random rand = new Random();
		Scanner sn = new Scanner(System.in);
		System.out.print("��ڼ�: ");
		int num = sn.nextInt();
		
		int[] a = new int[num];
		int[] b = new int[num];
		
		for(int i=0; i<a.length; i++) {
			a[i] = 1 + rand.nextInt(9);
		}
		
		copy(a, b);
		
		System.out.println("a: " + Arrays.toString(a));
		System.out.println("b: " + Arrays.toString(b));
	}

}
