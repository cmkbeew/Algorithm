package chap02.pracQ;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Rcopy {
	static void rcopy(int[] a, int[] b) {
		int num = a.length <= b.length ? a.length : b.length;
		for(int i=0; i<num; i++) {
			a[i] = b[b.length-i-1];
		}
	}
	public static void main(String[] args) {
		Random rand = new Random();
		Scanner sn = new Scanner(System.in);
		
		System.out.print("a�� ��ڼ�: ");
		int numa = sn.nextInt();
		int[] a = new int[numa];
		for(int i=0; i<a.length; i++) {
			a[i] = 1+ rand.nextInt(9);
		}
		System.out.println("�迭 a: " + Arrays.toString(a));
		
		System.out.print("b�� ��ڼ�: ");
		int numb = sn.nextInt();
		int[] b = new int[numb];
		for(int i=0; i<b.length; i++) {
			b[i] = 1+ rand.nextInt(9);
		}
		System.out.println("b: " + Arrays.toString(b));
		
		rcopy(a, b);
		
		System.out.println("�迭 b�� ��Ҹ� �迭 a�� �������� �����Ͽ����ϴ�.");
		System.out.println("�迭 a: " + Arrays.toString(a));
		System.out.println("�迭 b: " + Arrays.toString(b));
	}

}
