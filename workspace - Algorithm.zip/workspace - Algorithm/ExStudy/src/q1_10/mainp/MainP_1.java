package q1_10.mainp;

import java.util.ArrayList;
import java.util.Scanner;

import q1_10.Student;

public class MainP_1 {

	public static void main(String[] args) {
		Student st1 = new Student("Kim", "111");
		Student st2 = new Student("Lee", "222");
		Student st3 = new Student("Park", "333");
		Student st4 = new Student("Na", "444");
		Student st5 = new Student("Lim", "555");
		
		ArrayList<Student> list = new ArrayList<Student>();
		list.add(st1);
		list.add(st2);
		list.add(st3);
		list.add(st4);
		list.add(st5);
		
//		for(Student stu : list) {
//			System.out.println("Name: " + stu.getName());
//			System.out.println("No: " + stu.getNo());
//		}
		
		Scanner sn = new Scanner(System.in);
		
		while(true) {
			System.out.println("�˻� y | ���� n");
			String input = sn.next();
			
			if(input.equalsIgnoreCase("y")) {
				System.out.print("�˻��� �̸�: ");
				String name = sn.next();
				boolean flag = false;
				
				for(Student stu : list) {
					if(stu.getName().equals(name)) {
						System.out.println("Name: " + stu.getName() + ", No: " + stu.getNo());
						flag = true;
					}
				}
				
				if(!flag) {
					System.out.println("�˻��� �л��� ���������ʽ��ϴ�.");
				}
			}else if(input.equalsIgnoreCase("n")) {
				break;
			}
		}
		
		System.out.println("����Ǿ����ϴ�.");
	}

}
