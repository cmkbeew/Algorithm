package q1_10.mainp;

import java.util.Scanner;

// 10������ 2������ ��ȯ
public class MainP_4 {

	public static void main(String[] args) {
		Scanner sn = new Scanner(System.in);
		System.out.print("��ȯ�� ��: ");
		
		int inputNum = sn.nextInt();
		int[] bin = new int[100];
		
		int i = 0;
		int mok = inputNum;
		
		while(mok > 0) {
			bin[i] = mok % 2;
			mok /= 2;
			i++;
		}
		i--;
		
		for(; i>=0; i--) {
			System.out.print(bin[i]);
		}
	}

}
