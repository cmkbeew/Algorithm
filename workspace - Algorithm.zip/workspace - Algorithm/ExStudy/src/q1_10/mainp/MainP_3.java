package q1_10.mainp;

import java.util.Scanner;

public class MainP_3 {

	public static void main(String[] args) {
		Scanner sn = new Scanner(System.in);
		
		int[] inputNum = new int[10];
		
		for(int i=0; i<inputNum.length; i++) {
			inputNum[i] = sn.nextInt();
		}
		
		int[] mode = new int[10];
		
		for(int i=0; i<10; i++) {
			mode[inputNum[i]]++;
		}
		
		int modeNum = 0;
		int modeCnt = 0;
		
		for(int i=0; i<10; i++) {
			if(modeCnt < mode[i]) {
				modeCnt = mode[i];
				modeNum = i;
			}
		}
		
		System.out.println("�ֺ��: " + modeNum + ", ���� Ƚ��: " + modeCnt);
	}
}
